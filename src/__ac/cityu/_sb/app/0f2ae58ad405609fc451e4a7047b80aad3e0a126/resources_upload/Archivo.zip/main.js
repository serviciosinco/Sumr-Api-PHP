SUMR_AppCm = {  /* Custom Object App */
    stup:{
        org:{
            id:''
        },
        fm:{
            id:''
        }
    },
    routes:{
        pm1:'',
        module:'', 
    },
    grph:{
        tot_sales:{
            sbt:'',
            c:[],
            d:[]
        },
        tot_sales_m:{
            sbt:'',
            c:[],
            d:[]
        },
        tot_sales_y:{
            sbt:'',
            c:[],
            d:[]
        },
        tot_sales_t:{
            sbt:'',
            c:[],
            d:[]
        },
        tot_sales_tck:{
            sbt:'',
            c:[],
            d:[]
        }
    },
    fm:{ 
        id:'',
        bx_mdlfm:'',
        clmdlfm:{}, 
        mnt:'',
        mdlfm_itm:''
    },
    snd:function(p){

        if(!SUMR_Ld.f.isN(p) && !SUMR_Ld.f.isN(p.t) && !SUMR_Ld.f.isN(p.d)){
            
            if(SUMR_Ld.f.onl() && SUMR_Ld.f.isN(SUMR_RquClg.snd[p.t])){
                
                var route;

                if(!SUMR_Ld.f.isN(p.p) && p.p == 'sch'){ 
                    var _u = 'search'; 
                }else if(!SUMR_Ld.f.isN(p.p) && p.p == 'prc'){ 
                    var _u = 'process'; 
                }else if(!SUMR_Ld.f.isN(p.p) && p.p == 'data'){ 
                    var _u = 'data'; 
                }
                
                if(!SUMR_Ld.f.isN( SUMR_AppCm.routes.pm1 )){ route += SUMR_AppCm.routes.pm1+'/'; }
                if(!SUMR_Ld.f.isN( SUMR_AppCm.routes.pm2 )){ route += SUMR_AppCm.routes.pm2+'/'; }
                
                SUMR_RquClg.snd[p.t] = $.ajax({
                                                type:'POST',
                                                url: '/'+route+_u+'/',
                                                data: p.d,
                                                dataType: 'json',
                                                beforeSend: function() {
                                                    if(!SUMR_Ld.f.isN(p._bs)){ p._bs(); }
                                                },
                                                error:function(e){
                                                    if(!SUMR_Ld.f.isN(p._w)){ p._w(e); }
                                                },
                                                success:function(e){	
                                                    if(!SUMR_Ld.f.isN(p._cl)){ p._cl(e); }
                                                },
                                                complete:function(e){
                                                    SUMR_RquClg.snd[p.t] = '';
                                                    if(!SUMR_Ld.f.isN(p._cm)){ p._cm(e); }
                                                }
                                        });							
            }
        }
    },
    ldg:function(p){

        SUMR_Ld.f.js({ 
            t:'c',
            u:'js_grph.js',
            c:function(){
                if(!SUMR_Ld.f.isN(p) && !SUMR_Ld.f.isN(p.cl)){ p.cl(); }
                return true;
            }
        });

        return false
        
    },
    rndr_g:function (){

        try{

            if(!SUMR_Ld.f.isN(SUMR_Grph) && !SUMR_Ld.f.isN(SUMR_Grph.f)){

                SUMR_Grph.f.g1({ 
                    id: '#sales_this_month',
                    tt: ' ',
                    tt_sb: ' ',
                    plot_dl_y:-1,
                    c: SUMR_AppCm.grph.tot_sales_m.c,
                    d: SUMR_AppCm.grph.tot_sales_m.d,
                    c_e:true,
                    ttip_frmt:function(d){
                        if(!SUMR_Ld.f.isN(d) && !SUMR_Ld.f.isN(d.point)){
                            return '$' + Highcharts.numberFormat(d.y, 0, ',', '.');
                        }
                    },
                    plot_dl_e: false,
                    plot_dl_frmt:function(d){
                        if(!SUMR_Ld.f.isN(d) && !SUMR_Ld.f.isN(d.point)){    
                            if(!SUMR_Ld.f.isN( d.y )){
                                var point = d.point;
                                window.setTimeout(function () {
                                    point.dataLabel.attr({
                                        y: point.plotY - 20
                                    });
                                });
                            
                                return '$ ' + Highcharts.numberFormat(d.y, 0, ',', '.');
                            }
                        }
                    }
                });

                SUMR_Grph.f.g4({ 
                    id: '#sales_this_day',
                    c: SUMR_AppCm.grph.tot_sales.c,
                    d: SUMR_AppCm.grph.tot_sales.d,
                    tt: 'Ventas', 
                    tt_sb: 'Ventas por día',
                    c_e: false,
                    g_spc_l: 0,
                    ttip_frmt:function(d){
                        if(!SUMR_Ld.f.isN(d) && !SUMR_Ld.f.isN(d.point)){
                            return '$' + Highcharts.numberFormat(d.y, 0, ',', '.');
                        }
                    },
                });

                SUMR_Grph.f.g3({ 
                    id: '#sales_this_year',
                    c: SUMR_AppCm.grph.tot_sales_y.c,
                    d: SUMR_AppCm.grph.tot_sales_y.d,
                    tt: 'Ventas', 
                    tt_sb: 'Ventas por año acumulado',
                    c_e: false,
                    ttip_frmt:function(d){
                        if(!SUMR_Ld.f.isN(d) && !SUMR_Ld.f.isN(d.point)){
                            return '$' + Highcharts.numberFormat(d.y, 0, ',', '.');
                        }
                    }
                });

                SUMR_Grph.f.g4({ 
                    id: '#sales_this_tsr',
                    c: SUMR_AppCm.grph.tot_sales_t.c,
                    d: SUMR_AppCm.grph.tot_sales_t.d,
                    tt: 'Transacciones', 
                    tt_sb: 'Transacciones por día',
                    c_e: false,
                    g_spc_l: 0,
                    ttip_frmt:function(d){
                        if(!SUMR_Ld.f.isN(d) && !SUMR_Ld.f.isN(d.point)){
                            return '$' + Highcharts.numberFormat(d.y, 0, ',', '.');
                        }
                    }
                });

                SUMR_Grph.f.g4({ 
                    id: '#sales_this_tck',
                    c: SUMR_AppCm.grph.tot_sales_tck.c,
                    d: SUMR_AppCm.grph.tot_sales_tck.d,
                    tt: 'Tickets', 
                    tt_sb: 'Promedio de ticket por día',
                    c_e: false,
                    g_spc_l: 0,
                    ttip_frmt:function(d){
                        if(!SUMR_Ld.f.isN(d) && !SUMR_Ld.f.isN(d.point)){
                            return '$' + Highcharts.numberFormat(d.y, 0, ',', '.');
                        }
                    }
                });

            }

        }catch(e){    

            console.info(e);

        }
    },

    ClMdlFm_Html:function(){
        SUMR_AppCm.fm.bx_mdlfm.html('');
                                
        $.each(SUMR_AppCm.fm.clmdlfm['ls'], function(k, v) {

            if(!SUMR_Ld.f.isN(v.vl)){ var valor = v.vl; }else{  var valor = 0; }

            SUMR_AppCm.fm.bx_mdlfm.append('<div id=\"'+v.enc+'\" class=\"clds_cont\"><div class=\"val\" >'+valor+'</div><div class=\"trs\">'+v.trs+'</div><div class=\"f\">'+v.f+'</div><div class=\"edt\"><button></button></div></div>');
        });	

        SUMR_AppCm.Dom_Rbld();       
    }, 

    OnlyMonth:function(){
        var sls = $('#orgsdsarrsls_vl').val();
                
        if(sls > 0){ $('#orgsdsarrsls_vl').show(); }else{ $('#orgsdsarrsls_vl').hide(); }
        
        $('#orgsdsarrsls_f').on('change',function(){

            var date_slc = $(this).val();

            var date = new Date(date_slc);
            var ultimoDia = new Date(date.getFullYear(), date.getMonth()+1, 0);

            var dia  = ultimoDia.getDate();

            var dates = new Date(date_slc);
            dates = dates.getDate() + 1;

            if(dates == dia){ $('#orgsdsarrsls_vl').show(); }else{ $('#orgsdsarrsls_vl').hide().val(0);	}
        });    
    },

    Logt:function (){
        $('.lgt').off('click').click(function(e){ 
            swal({
                title: '¿Seguro deseas cerrar la sesión?',
                type: 'warning',
                showCancelButton: true,
                closeOnConfirm: true,
                showLoaderOnConfirm: false,
            },
            function(){
                SUMR_AppCm.f.snd({
                    p: 'data',
                    t: 'org_sds_arr_sls',
                    d:{ t: 'logout' },
                    _bs:function(){ },
                    _cl:function(r){
                        if(r.e == 'ok'){
                            location.href = '/'+SUMR_AppCm.routes.pm1+'/'+SUMR_AppCm.routes.module+'/dashboard/'
                        }
                    },
                    _cm:function(r){ },
                    _w:function(r){ }
                });
            }); 
        });
    },

    Dom_Rbld:function (){

        SUMR_AppCm.fm.id = $('#form_marks');
        SUMR_AppCm.fm.bx_mdlfm = $('#valores');
        SUMR_AppCm.fm.mdlfm_itm = $('#valores .edt');

        $("#send_form").off("click").click(function() {                       
            window.location.href = window.location.pathname+'/dashboard/';
        });

        $('#send_form_sles').off('click').click(function(event){
            event.preventDefault();
            SUMR_AppCm._sndData({ id:SUMR_AppCm.stup.org.id });	
        });
    
        $("#btn_new_sles").off("click").click(function() {   console.log('Open Colorbox');    
        
            $('.__chk_vl ._vl').html(0);
            $('#orgsdsarrsls_f').show();

            if(SUMR_AppCm.fm.mnt == 1){ $('#orgsdsarrsls_vl').hide(); }

            $.colorbox({ 
                width:'400', 
                height:'500', 
                inline:true, 
                href:"#new_sles_form",
                onClosed: function(){

                    $('#orgsdsarrsls_vl').val('');
                    $('#orgsdsarrsls_trs').val('');
                    $('#orgsdsarrsls_f').val('');
                    $('#orgsdsarr_sls_tp_bd').val('Insert');
                    $('#orgsdsarrsls_enc').val('');

                } 
            });
        });

        SUMR_AppCm.fm.mdlfm_itm.not('.sch').off('click').click(function(){

            var id = $(this).parent().attr('id');

            var vl = $('#'+id+' .val').html();
            var trs = $('#'+id+' .trs').html();
            var f = $('#'+id+' .f').html();

            $.colorbox({ 
                width:'400', 
                height:'500', 
                inline:true, 
                href:'#new_sles_form',
                onClosed: function(){
                    $('#orgsdsarrsls_vl').val('');
                    $('#orgsdsarrsls_trs').val('');
                    $('#orgsdsarrsls_f').val('');
                    $('#orgsdsarr_sls_tp_bd').val('Insert');
                    $('#orgsdsarrsls_enc').val('');
                } 
            });

            $('.__chk_vl ._vl').html(0);
            let _num_frmt = vl.replace(/\./g,'');
            _num_frmt = _num_frmt.toString().split('').reverse().join('').replace(/(?=\d*\.?)(\d{3})/g,'$1.');
            _num_frmt = _num_frmt.split('').reverse().join('').replace(/^[\.]/,'');
            $('#new_sles_form .__chk_vl ._vl').html(_num_frmt);

            $('#orgsdsarrsls_f').hide(); 

            if(vl > 0){
                $('#orgsdsarrsls_vl').show();   
            }

            $('#orgsdsarrsls_vl').val(vl);
            $('#orgsdsarrsls_trs').val(trs);
            $('#orgsdsarrsls_f').val(f);
            $('#orgsdsarr_sls_tp_bd').val('Update');
            $('#orgsdsarrsls_enc').val(id);

        });
    
    
        try{
    
            $('#orgsdsarrsls_vl').keyup(function(p){
                if( !SUMR_Ld.f.isN($(this).val()) ){
                    if( isNaN($(this).val()) ){
                        $('.__chk_vl ._vl').html('Numero no valido');
                        $('.__chk_vl ._vl').addClass('_err');
                    }else{
                        $('.__chk_vl ._vl').removeClass('_err');
                        let _num_frmt = $(this).val().replace(/\./g,'');
                        _num_frmt = _num_frmt.toString().split('').reverse().join('').replace(/(?=\d*\.?)(\d{3})/g,'$1.');
                        _num_frmt = _num_frmt.split('').reverse().join('').replace(/^[\.]/,'');
                        $('.__chk_vl ._vl').html(_num_frmt);
                    }
                }else{
                    $('.__chk_vl ._vl').html(0);
                }
            });
    
        }catch(err) {
            log('Error en div __chk_vl:'+err.message);
        }
    
        
        $('.pin').off('click').click(function(e){ 
            e.preventDefault();

            $.ajax({
                type:'POST',
                url: SUMR_AppCm.routes.module+'/process/login/',
                data: $('#'+SUMR_AppCm.stup.fm.id).serialize(),
                dataType: 'json',
                beforeSend: function() { 
                    $('.__fm').addClass('_ld');
                },
                complete:function(e){
                    $('.__fm').removeClass('_ld');
                },
                success:function(r){	
                    if(r.e == 'ok'){
                        location.href = '/'+SUMR_AppCm.routes.pm1+'/'+SUMR_AppCm.routes.module+'/dashboard/?i='+r.data.org.enc      
                    }else{
                        swal('Error al intertar ingresar', 'Por favor confirma tus datos', 'error');
                    }
                }
            });
        });

    },

    AppSet:function(p){
        if( !SUMR_Ld.f.isN(p) ){
            if( !SUMR_Ld.f.isN(p) ){ SUMR_AppCm.fm.clmdlfm['ls'] = p.ls; }
            SUMR_AppCm.ClMdlFm_Html();
        }
    },

    _sndData:function(p){

        if(SUMR_AppCm.fm.id.valid()){
                
            SUMR_AppCm.f.snd({
                p: 'prc',
                t:'org_sds_arr_sls',
                d:SUMR_AppCm.fm.id.serialize(),
                _bs:function(){ },
                _cl:function(r){
                    if(r.e == 'ok'){
                        SUMR_AppCm.snd({
                            p: 'data',
                            t: 'org_sds_arr',
                            d: {
                                i:SUMR_AppCm.stup.org.id
                            },
                            _bs:function(){ },
                            _cl:function(r){
                                if(r.app.e == 'ok'){ 
                                    SUMR_AppCm.AppSet(r.app);
                                    $.colorbox.close();
                                    location.reload();
                                }
                            },
                            _cm:function(r){  },
                            _w:function(r){ }
                        });   
                    }else if(!SUMR_Ld.f.isN(r.msj)){
                        swal('Error!', r.msj, 'error');
                    }
                },
                _cm:function(r){ },
                _w:function(r){
                    console.log('error');
                }
            });
        }
    }

};




